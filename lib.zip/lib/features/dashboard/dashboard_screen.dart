// features/dashboard/dashboard_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/widgets/app_badge.dart';
import '../../core/widgets/app_card.dart';
import 'providers/dashboard_provider.dart';

// ── Screen ────────────────────────────────────────────────
class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});

  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _entrance;

  late final Animation<double> _heroAnim;
  late final Animation<double> _overviewAnim;
  late final Animation<double> _actionsAnim;
  late final Animation<double> _plotAnim;

  @override
  void initState() {
    super.initState();
    _entrance = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1300),
    );

    _heroAnim = CurvedAnimation(
      parent: _entrance,
      curve: const Interval(0.0, 0.45, curve: Curves.easeOutCubic),
    );
    _overviewAnim = CurvedAnimation(
      parent: _entrance,
      curve: const Interval(0.15, 0.65, curve: Curves.easeOutCubic),
    );
    _actionsAnim = CurvedAnimation(
      parent: _entrance,
      curve: const Interval(0.35, 0.85, curve: Curves.easeOutCubic),
    );
    _plotAnim = CurvedAnimation(
      parent: _entrance,
      curve: const Interval(0.55, 1.0, curve: Curves.easeOutCubic),
    );

    _entrance.forward();
  }

  @override
  void dispose() {
    _entrance.dispose();
    super.dispose();
  }

  Widget _rise(Animation<double> anim, Widget child) {
    return AnimatedBuilder(
      animation: anim,
      child: child,
      builder: (context, child) {
        final v = anim.value.clamp(0.0, 1.0);
        return Opacity(
          opacity: v,
          child: Transform.translate(
            offset: Offset(0, (1 - v) * 24),
            child: child,
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final checkIn = ref.watch(checkInProvider);
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AnimatedBuilder(
              animation: _heroAnim,
              child: _HeroBanner(checkIn: checkIn),
              builder: (context, child) {
                final v = _heroAnim.value.clamp(0.0, 1.0);
                return Opacity(
                  opacity: v,
                  child: Transform.translate(
                    offset: Offset(0, (1 - v) * -20),
                    child: child,
                  ),
                );
              },
            ),
            _rise(
              _overviewAnim,
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 24, 16, 0),
                child: Row(
                  children: [
                    const Icon(Icons.bar_chart_outlined,
                        size: 15, color: AppColors.textDisabled),
                    const SizedBox(width: 6),
                    Text('Overview',
                        style: AppTextStyles.label
                            .copyWith(color: AppColors.textSecondary)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            _KpiGrid(reveal: _overviewAnim),
            _rise(
              _actionsAnim,
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 28, 16, 12),
                child: Row(
                  children: [
                    const Icon(Icons.bolt_outlined,
                        size: 15, color: AppColors.textDisabled),
                    const SizedBox(width: 6),
                    Text('Quick Actions',
                        style: AppTextStyles.label
                            .copyWith(color: AppColors.textSecondary)),
                  ],
                ),
              ),
            ),
            _QuickActions(reveal: _actionsAnim),
            _rise(
              _plotAnim,
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 28, 16, 12),
                child: Row(
                  children: [
                    const Icon(Icons.map_outlined,
                        size: 15, color: AppColors.textDisabled),
                    const SizedBox(width: 6),
                    Text('Plot Overview',
                        style: AppTextStyles.label
                            .copyWith(color: AppColors.textSecondary)),
                  ],
                ),
              ),
            ),
            _PlotOverviewTeaser(reveal: _plotAnim),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}

// ── Hero Banner ───────────────────────────────────────────
class _HeroBanner extends ConsumerStatefulWidget {
  const _HeroBanner({required this.checkIn});
  final CheckInState checkIn;

  @override
  ConsumerState<_HeroBanner> createState() => _HeroBannerState();
}

class _HeroBannerState extends ConsumerState<_HeroBanner>
    with TickerProviderStateMixin {
  // Slow "breathing" gradient — the light source drifts across the
  // banner instead of sitting static.
  late final AnimationController _gradientShift;
  // Radar-style ping rings around the status dot while checked in.
  late final AnimationController _ping;
  // One-shot confirm bounce, played the moment isCheckedIn flips true.
  late final AnimationController _confirm;

  bool _prevCheckedIn = false;

  @override
  void initState() {
    super.initState();
    _prevCheckedIn = widget.checkIn.isCheckedIn;

    _gradientShift = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 7),
    )..repeat(reverse: true);

    _ping = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat();

    _confirm = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 550),
    );
  }

  @override
  void didUpdateWidget(covariant _HeroBanner oldWidget) {
    super.didUpdateWidget(oldWidget);
    final justCheckedIn = widget.checkIn.isCheckedIn && !_prevCheckedIn;
    if (justCheckedIn) {
      _confirm.forward(from: 0);
    }
    _prevCheckedIn = widget.checkIn.isCheckedIn;
  }

  @override
  void dispose() {
    _gradientShift.dispose();
    _ping.dispose();
    _confirm.dispose();
    super.dispose();
  }

  String get _greeting {
    final h = DateTime.now().hour;
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  }

  String get _todayLabel =>
      DateFormat('EEEE, d MMM yyyy').format(DateTime.now());

  @override
  Widget build(BuildContext context) {
    final checkIn = widget.checkIn;
    return AnimatedBuilder(
      animation: _gradientShift,
      builder: (context, child) {
        final t = _gradientShift.value; // 0..1..0
        return Container(
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: const [
                Color(0xFF1B4332),
                Color(0xFF2D6A4F),
                Color(0xFF40916C),
              ],
              begin: Alignment(-1.0 + t * 0.6, -1.0 - t * 0.3),
              end: Alignment(1.0 - t * 0.3, 1.0 + t * 0.3),
            ),
          ),
          child: child,
        );
      },
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _greeting,
                          style: AppTextStyles.body.copyWith(
                            color: Colors.white.withOpacity(0.75),
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'Field Officer',
                          style: AppTextStyles.h1.copyWith(
                            color: Colors.white,
                            fontSize: 26,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            const Icon(Icons.calendar_today_outlined,
                                size: 12, color: Colors.white54),
                            const SizedBox(width: 4),
                            Text(
                              _todayLabel,
                              style: AppTextStyles.caption
                                  .copyWith(color: Colors.white54),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(20),
                      border:
                          Border.all(color: Colors.white.withOpacity(0.2)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.location_on_outlined,
                            size: 12, color: Colors.white70),
                        const SizedBox(width: 4),
                        Text(
                          'Kothamangalam',
                          style: AppTextStyles.caption
                              .copyWith(color: Colors.white70),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              // Check-in card — bounces once when you check in
              AnimatedBuilder(
                animation: _confirm,
                builder: (context, child) {
                  final b = _confirm.value;
                  final bump = b < 0.5
                      ? 1.0 + (b / 0.5) * 0.045
                      : 1.045 - ((b - 0.5) / 0.5) * 0.045;
                  final scale = _confirm.isAnimating ? bump : 1.0;
                  return Transform.scale(scale: scale, child: child);
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 350),
                  curve: Curves.easeOut,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.10),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: checkIn.isCheckedIn
                          ? const Color(0xFF52B788).withOpacity(0.4)
                          : Colors.white.withOpacity(0.15),
                    ),
                  ),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 22,
                        height: 22,
                        child: AnimatedBuilder(
                          animation: _ping,
                          builder: (context, _) {
                            if (!checkIn.isCheckedIn) {
                              return const Center(
                                child: _StatusDot(active: false),
                              );
                            }
                            return Stack(
                              alignment: Alignment.center,
                              children: [
                                _RadarRing(progress: _ping.value),
                                _RadarRing(
                                  progress: (_ping.value + 0.5) % 1.0,
                                ),
                                const _StatusDot(active: true),
                              ],
                            );
                          },
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: AnimatedSwitcher(
                          duration: const Duration(milliseconds: 250),
                          transitionBuilder: (child, anim) => FadeTransition(
                            opacity: anim,
                            child: SlideTransition(
                              position: Tween<Offset>(
                                begin: const Offset(0, 0.25),
                                end: Offset.zero,
                              ).animate(anim),
                              child: child,
                            ),
                          ),
                          child: Text(
                            checkIn.isCheckedIn
                                ? 'Checked in · ${checkIn.time}'
                                : 'Not checked in yet',
                            key: ValueKey(checkIn.isCheckedIn),
                            style: AppTextStyles.body.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                      _PressableScale(
                        onTap: checkIn.isCheckedIn
                            ? () => ref
                                .read(checkInProvider.notifier)
                                .checkOut()
                            : () =>
                                ref.read(checkInProvider.notifier).checkIn(),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 8),
                          decoration: BoxDecoration(
                            color: checkIn.isCheckedIn
                                ? Colors.white.withOpacity(0.15)
                                : Colors.white,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              AnimatedSwitcher(
                                duration: const Duration(milliseconds: 250),
                                transitionBuilder: (child, anim) =>
                                    ScaleTransition(
                                        scale: anim, child: child),
                                child: Icon(
                                  checkIn.isCheckedIn
                                      ? Icons.logout_rounded
                                      : Icons.check_circle_outline_rounded,
                                  key: ValueKey(checkIn.isCheckedIn),
                                  size: 15,
                                  color: checkIn.isCheckedIn
                                      ? Colors.white
                                      : AppColors.primary,
                                ),
                              ),
                              const SizedBox(width: 6),
                              AnimatedSwitcher(
                                duration: const Duration(milliseconds: 200),
                                child: Text(
                                  checkIn.isCheckedIn
                                      ? 'Check Out'
                                      : 'Check In',
                                  key: ValueKey(checkIn.isCheckedIn),
                                  style: AppTextStyles.label.copyWith(
                                    color: checkIn.isCheckedIn
                                        ? Colors.white
                                        : AppColors.primary,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusDot extends StatelessWidget {
  const _StatusDot({required this.active});
  final bool active;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 10,
      height: 10,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: active ? const Color(0xFF52B788) : Colors.white38,
      ),
    );
  }
}

// Expanding, fading ring — classic "live/active" radar-ping effect.
class _RadarRing extends StatelessWidget {
  const _RadarRing({required this.progress});
  final double progress; // 0..1

  @override
  Widget build(BuildContext context) {
    final size = 10.0 + progress * 16;
    final opacity = (1 - progress).clamp(0.0, 1.0) * 0.55;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(
          color: const Color(0xFF52B788).withOpacity(opacity),
          width: 1.4,
        ),
      ),
    );
  }
}

// ── Reusable press-scale wrapper ───────────────────────────
class _PressableScale extends StatefulWidget {
  const _PressableScale({required this.child, required this.onTap});
  final Widget child;
  final VoidCallback onTap;

  @override
  State<_PressableScale> createState() => _PressableScaleState();
}

class _PressableScaleState extends State<_PressableScale> {
  double _scale = 1.0;

  void _setScale(double s) => setState(() => _scale = s);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      onTapDown: (_) => _setScale(0.94),
      onTapUp: (_) => _setScale(1.0),
      onTapCancel: () => _setScale(1.0),
      child: AnimatedScale(
        scale: _scale,
        duration: const Duration(milliseconds: 120),
        curve: Curves.easeOut,
        child: widget.child,
      ),
    );
  }
}

// ── Pop-in wrapper: fade + upward slide + elastic scale + a touch of
// rotation, sliced into per-item stagger windows off a parent reveal
// animation. This is the "real" entrance animation, not just a fade.
class _PopIn extends StatelessWidget {
  const _PopIn({
    required this.reveal,
    required this.index,
    required this.total,
    required this.child,
    this.fromLeft = false,
  });
  final Animation<double> reveal;
  final int index;
  final int total;
  final Widget child;
  final bool fromLeft;

  @override
  Widget build(BuildContext context) {
    final start = (index / total).clamp(0.0, 1.0);
    final end = ((index + 1) / total).clamp(0.0, 1.0);
    final local = CurvedAnimation(
      parent: reveal,
      curve: Interval(start, end, curve: Curves.elasticOut),
    );
    final fade = CurvedAnimation(
      parent: reveal,
      curve: Interval(start, end, curve: Curves.easeOut),
    );
    return AnimatedBuilder(
      animation: reveal,
      child: child,
      builder: (context, child) {
        final v = local.value; // unclamped — allowed to overshoot
        final opacity = fade.value.clamp(0.0, 1.0);
        final dx = fromLeft ? (1 - v) * -40 : (1 - v) * 40;
        return Opacity(
          opacity: opacity,
          child: Transform.translate(
            offset: Offset(dx, (1 - v) * 18),
            child: Transform.scale(
              scale: 0.7 + v * 0.3,
              child: Transform.rotate(
                angle: (1 - v) * (fromLeft ? -0.06 : 0.06),
                child: child,
              ),
            ),
          ),
        );
      },
    );
  }
}

// ── KPI Grid ──────────────────────────────────────────────
class _KpiGrid extends ConsumerWidget {
  const _KpiGrid({required this.reveal});
  final Animation<double> reveal;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final kpis = ref.watch(dashboardKpisProvider);

    final areaAcres = kpis.totalAreaAcres;
    final co2eT = kpis.totalCo2eTonnes;
    final isNetNegative = kpis.totalCo2eKg <= 0;

    final items = [
      _KpiItem(
        value: kpis.totalFarmers.toDouble(),
        decimals: 0,
        label: 'Farmers',
        icon: Icons.people_outline,
        iconColor: AppColors.primary,
        iconBg: AppColors.successBg,
      ),
      _KpiItem(
        value: kpis.totalPlots.toDouble(),
        decimals: 0,
        label: 'Plots',
        icon: Icons.location_on_outlined,
        iconColor: AppColors.info,
        iconBg: AppColors.infoBg,
      ),
      _KpiItem(
        value: areaAcres,
        decimals: 1,
        label: 'Acres',
        icon: Icons.terrain_outlined,
        iconColor: AppColors.warning,
        iconBg: AppColors.warningBg,
      ),
      _KpiItem(
        value: kpis.activeSeasons.toDouble(),
        decimals: 0,
        label: 'Seasons',
        icon: Icons.grass_outlined,
        iconColor: AppColors.stagePlanting,
        iconBg: AppColors.stagePlantingBg,
      ),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          Row(
            children: List.generate(items.length, (i) {
              final k = items[i];
              return Expanded(
                child: Padding(
                  padding:
                      EdgeInsets.only(right: i == items.length - 1 ? 0 : 10),
                  child: _PopIn(
                    reveal: reveal,
                    index: i,
                    total: items.length,
                    fromLeft: i.isEven,
                    child: _KpiCard(item: k, reveal: reveal, index: i),
                  ),
                ),
              );
            }),
          ),
          const SizedBox(height: 10),
          _PopIn(
            reveal: reveal,
            index: items.length,
            total: items.length + 1,
            child: AppCard(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  _BreathingIcon(
                    icon: Icons.eco_outlined,
                    color: AppColors.primary,
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Carbon Footprint',
                            style: AppTextStyles.caption),
                        const SizedBox(height: 2),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            TweenAnimationBuilder<double>(
                              tween: Tween(begin: 0, end: co2eT),
                              duration: const Duration(milliseconds: 1100),
                              curve: Curves.easeOutCubic,
                              builder: (context, value, _) {
                                return Text(
                                  value.toStringAsFixed(1),
                                  style: AppTextStyles.h1.copyWith(
                                    color: isNetNegative
                                        ? AppColors.primary
                                        : AppColors.warning,
                                    fontSize: 28,
                                    fontWeight: FontWeight.w700,
                                  ),
                                );
                              },
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(bottom: 3, left: 4),
                              child: Text(
                                'tCO₂e net',
                                style: AppTextStyles.caption
                                    .copyWith(color: AppColors.textSecondary),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  AppStatusBadge(
                    label: kpis.isLowEmissions
                        ? 'Low Emissions'
                        : 'High Emissions',
                    variant: kpis.isLowEmissions
                        ? BadgeVariant.success
                        : BadgeVariant.warning,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Slow, continuous scale pulse — used on icon badges that should feel
// "alive" even once the entrance animation has finished.
class _BreathingIcon extends StatefulWidget {
  const _BreathingIcon({required this.icon, required this.color});
  final IconData icon;
  final Color color;

  @override
  State<_BreathingIcon> createState() => _BreathingIconState();
}

class _BreathingIconState extends State<_BreathingIcon>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        final scale = 1.0 + _c.value * 0.06;
        return Transform.scale(
          scale: scale,
          child: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: LinearGradient(
                colors: [
                  widget.color.withOpacity(0.15 + _c.value * 0.05),
                  widget.color.withOpacity(0.28 + _c.value * 0.05),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Icon(widget.icon, color: widget.color, size: 24),
          ),
        );
      },
    );
  }
}

class _KpiItem {
  final double value;
  final int decimals;
  final String label;
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  const _KpiItem({
    required this.value,
    required this.decimals,
    required this.label,
    required this.icon,
    required this.iconColor,
    required this.iconBg,
  });
}

class _KpiCard extends StatelessWidget {
  const _KpiCard(
      {required this.item, required this.reveal, required this.index});
  final _KpiItem item;
  final Animation<double> reveal;
  final int index;

  @override
  Widget build(BuildContext context) {
    final iconAnim = CurvedAnimation(
      parent: reveal,
      curve: Interval(
        (0.15 + index * 0.05).clamp(0.0, 1.0),
        1.0,
        curve: Curves.elasticOut,
      ),
    );

    return AppCard(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AnimatedBuilder(
            animation: iconAnim,
            builder: (context, _) {
              final v = iconAnim.value;
              return Transform.rotate(
                angle: (1 - v) * 0.5,
                child: Transform.scale(
                  scale: v.clamp(0.0, 1.4),
                  child: Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: item.iconBg,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(item.icon, size: 16, color: item.iconColor),
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 10),
          TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: item.value),
            duration: const Duration(milliseconds: 900),
            curve: Curves.easeOutCubic,
            builder: (context, value, _) {
              return Text(
                value.toStringAsFixed(item.decimals),
                style: AppTextStyles.h2.copyWith(
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              );
            },
          ),
          const SizedBox(height: 2),
          Text(item.label, style: AppTextStyles.caption),
        ],
      ),
    );
  }
}

// ── Quick Actions ─────────────────────────────────────────
class _QuickActions extends StatelessWidget {
  const _QuickActions({required this.reveal});
  final Animation<double> reveal;

  @override
  Widget build(BuildContext context) {
    final actions = [
      _QuickAction(
        icon: Icons.people_outline,
        label: 'Farmers',
        sublabel: 'View & manage',
        iconColor: AppColors.primary,
        iconBg: AppColors.successBg,
        onTap: () => context.go('/farmers'),
      ),
      _QuickAction(
        icon: Icons.person_add_outlined,
        label: 'Add Farmer',
        sublabel: 'Register new',
        iconColor: AppColors.info,
        iconBg: AppColors.infoBg,
        onTap: () => context.push('/add-farmer'),
      ),
      _QuickAction(
        icon: Icons.grass_outlined,
        label: 'Crops',
        sublabel: 'Seasons & stages',
        iconColor: AppColors.stagePlanting,
        iconBg: AppColors.stagePlantingBg,
        onTap: () => context.go('/crops'),
      ),
      _QuickAction(
        icon: Icons.eco_outlined,
        label: 'Carbon',
        sublabel: 'Track emissions',
        iconColor: AppColors.stageHarvest,
        iconBg: AppColors.stageHarvestBg,
        onTap: () => context.go('/carbon'),
      ),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.count(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        childAspectRatio: 1.75,
        children: List.generate(actions.length, (i) {
          return _PopIn(
            reveal: reveal,
            index: i,
            total: actions.length,
            fromLeft: i.isEven,
            child: _QuickActionCard(action: actions[i]),
          );
        }),
      ),
    );
  }
}

class _QuickAction {
  final IconData icon;
  final String label;
  final String sublabel;
  final Color iconColor;
  final Color iconBg;
  final VoidCallback onTap;
  const _QuickAction({
    required this.icon,
    required this.label,
    required this.sublabel,
    required this.iconColor,
    required this.iconBg,
    required this.onTap,
  });
}

class _QuickActionCard extends StatelessWidget {
  const _QuickActionCard({required this.action});
  final _QuickAction action;

  @override
  Widget build(BuildContext context) {
    return _PressableScale(
      onTap: action.onTap,
      child: AppCard(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: action.iconBg,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(action.icon, size: 20, color: action.iconColor),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    action.label,
                    style: AppTextStyles.labelLarge,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    action.sublabel,
                    style: AppTextStyles.caption,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios_rounded,
                size: 12, color: AppColors.textDisabled),
          ],
        ),
      ),
    );
  }
}

// ── Plot Overview Teaser ──────────────────────────────────
class _PlotOverviewTeaser extends ConsumerStatefulWidget {
  const _PlotOverviewTeaser({required this.reveal});
  final Animation<double> reveal;

  @override
  ConsumerState<_PlotOverviewTeaser> createState() =>
      _PlotOverviewTeaserState();
}

class _PlotOverviewTeaserState extends ConsumerState<_PlotOverviewTeaser>
    with TickerProviderStateMixin {
  late final AnimationController _float;
  late final AnimationController _shimmer;

  @override
  void initState() {
    super.initState();
    _float = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat(reverse: true);

    _shimmer = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2600),
    )..repeat();
  }

  @override
  void dispose() {
    _float.dispose();
    _shimmer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final kpis = ref.watch(dashboardKpisProvider);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: _PopIn(
        reveal: widget.reveal,
        index: 0,
        total: 1,
        child: _PressableScale(
          onTap: () => context.go('/plots'),
          child: Container(
            height: 170,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: const LinearGradient(
                colors: [Color(0xFF1B4332), Color(0xFF2D6A4F)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.3),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final w = constraints.maxWidth;
                  return Stack(
                    children: [
                      AnimatedBuilder(
                        animation: _float,
                        builder: (context, _) {
                          final t = _float.value;
                          return Stack(
                            children: [
                              Positioned(
                                right: -20 + t * 10,
                                top: -10 - t * 8,
                                child: Opacity(
                                  opacity: 0.15,
                                  child: Container(
                                    width: 140,
                                    height: 140,
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF74C69D),
                                      borderRadius: BorderRadius.circular(60),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                right: 40 - t * 12,
                                bottom: -20 + t * 10,
                                child: Opacity(
                                  opacity: 0.10,
                                  child: Container(
                                    width: 100,
                                    height: 100,
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF52B788),
                                      borderRadius: BorderRadius.circular(40),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 80 + t * 8,
                                top: 20 - t * 6,
                                child: Opacity(
                                  opacity: 0.08,
                                  child: Container(
                                    width: 70,
                                    height: 70,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                      AnimatedBuilder(
                        animation: _shimmer,
                        builder: (context, _) {
                          final t = _shimmer.value;
                          final dx = -0.5 * w + t * (w * 1.8);
                          // Positioned must be a direct child of Stack —
                          // IgnorePointer goes *inside* it, not around it.
                          return Positioned(
                            top: -40,
                            bottom: -40,
                            left: dx,
                            width: 70,
                            child: IgnorePointer(
                              child: Transform.rotate(
                                angle: -0.4,
                                child: Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.centerLeft,
                                      end: Alignment.centerRight,
                                      colors: [
                                        Colors.white.withOpacity(0),
                                        Colors.white.withOpacity(0.10),
                                        Colors.white.withOpacity(0),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                      Padding(
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 5),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.15),
                                    borderRadius: BorderRadius.circular(20),
                                    border: Border.all(
                                        color:
                                            Colors.white.withOpacity(0.2)),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const Icon(Icons.satellite_alt_outlined,
                                          size: 12, color: Colors.white70),
                                      const SizedBox(width: 4),
                                      Text('Live Map',
                                          style: AppTextStyles.caption
                                              .copyWith(
                                                  color: Colors.white70)),
                                    ],
                                  ),
                                ),
                                const Spacer(),
                                Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.15),
                                    shape: BoxShape.circle,
                                  ),
                                  child: const Icon(Icons.open_in_full,
                                      size: 13, color: Colors.white),
                                ),
                              ],
                            ),
                            const Spacer(),
                            Row(
                              children: [
                                _TeaserStat(
                                  value: kpis.totalPlots.toDouble(),
                                  decimals: 0,
                                  label: 'Plots mapped',
                                ),
                                const SizedBox(width: 24),
                                _TeaserStat(
                                  value: kpis.totalAreaAcres,
                                  decimals: 0,
                                  label: 'Acres covered',
                                ),
                                const Spacer(),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 14, vertical: 8),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        'Open map',
                                        style: AppTextStyles.label.copyWith(
                                          color: AppColors.primary,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                      const SizedBox(width: 4),
                                      const Icon(Icons.arrow_forward_rounded,
                                          size: 13, color: AppColors.primary),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _TeaserStat extends StatelessWidget {
  const _TeaserStat({
    required this.value,
    required this.decimals,
    required this.label,
  });
  final double value;
  final int decimals;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: value),
          duration: const Duration(milliseconds: 900),
          curve: Curves.easeOutCubic,
          builder: (context, v, _) {
            return Text(
              v.toStringAsFixed(decimals),
              style: AppTextStyles.h2.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                fontSize: 22,
              ),
            );
          },
        ),
        Text(
          label,
          style: AppTextStyles.caption.copyWith(color: Colors.white60),
        ),
      ],
    );
  }
}